#!/bin/bash
#  $1 source file name
#  $2 put file name
ndisasm  $1
