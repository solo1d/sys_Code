#!/bin/bash
#  $1 source file name

SEEK_POS=0
BS=512
COUNT=1

if [ "$2" != "" ] ; then
	SEEK_POS=$2
fi

if [ "$3" != "" ] ; then
	BS=$3
fi

COUNT_TEMP=`wc "$1" | awk '{ print $3}'`
if [ "${COUNT_TEMP}" -ge "${BS}" ] ; then
	COUNT=$((${COUNT_TEMP}/${BS} +1))
fi


echo "BS=${BS}"
echo "COUNT=${COUNT}"
echo "SEEK_POS=${SEEK_POS}"



dd if=$1 of=hd60M.img bs=${BS} count=${COUNT} conv=notrunc  seek=${SEEK_POS}
