#!/bin/bash
xxd -u -a -g 1 -seek 0 -l 61440 $1
