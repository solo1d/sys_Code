#!/bin/bash
#  $1 put file name
#  $2 source file name
nasm -I ./src/boot/include -o  $1  ./src/boot/$2  || echo "nasm Error" 

echo " === nasm OK === "

if [ "$1" !=  "mbr.bin" ] ; then
	exit
fi

echo "rundd.sh $1 0"
./rundd.sh $1
