#!/bin/bash

bochs -f ./bochsrc.disk