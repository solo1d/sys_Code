#ifndef __LIB_KERNEL_BITMAP_H
#define __LIB_KERNEL_BITMAP_H
#include "global.h"
#include "stdint.h"
#define BITMAP_MASK  1
struct bitmap {
    uint32_t btmp_bytes_len;    // 记录bits 的长度，也就是位图的长度
    /* 在遍历位图时、 整体上以字节为单位，细节上是以位为单位， 所以此处位图的指针必须是单字节 */ 
    uint8_t* bits;
};

void bitmap_init (struct bitmap* btmp); /* 将位图 bitmap 初始化 */
bool bitmap_scan_test (struct bitmap* btmp, uint32_t bit_idx); /* 判断 bit_idx 位是否为1， 若为1，则返回true， 否则返回 false */
int  bitmap_scan (struct bitmap* btmp, uint32_t cnt);          /* 在位图中申请连续 cnt 个位， 成功 则返回其起始位下标， 失败返回-1 */
void bitmap_set (struct bitmap * btmp, uint32_t bit_idx, int8_t value); /* 将位图 btmp 的 bit_idx 位设置为 value */
#endif