/**************** 机器模式 ******************************
 *  b -- 输出寄存器 Qimode 名称，即寄存器中的 最低8为 :[a-d] l
 *  w -- 输出寄存器 Himode 名称，即寄存器中2个字节的部分， 如 [a-d] x
 * 
 * Himode
 * 			"Half - Integer" 模式，表示一个两字节的整数
 * QImode
 * 			"Quarter - Integer" 模式，表示一个 一字节的整数
 *******************************************************/

#ifndef __LIB_IO_H
#define __LIB_IO_H
#include "stdint.h"

/* 向端口 port 写入一个字节 */
static inline void outb(uint16_t port, uint8_t data)
{
	/* 对端口指定N表示 0~255整数， d 代表用dx 存储端口号， %b0 表示对应的al, %w1 表示对应 dx */

	asm volatile ("outb %b0, %w1" : : "a"(data), "Nd"(port));		// 这个是AT&T汇编，操作数反过来
}


/* 将 addr 起始处的 word_cnt 个字节写入端口 port */
static inline void outsw(uint16_t port, const void* addr, uint32_t word_cnt)
{
	/*  把 ds:esi 处的16位的内容写入 port端口。  */
	/*  + 表示即使输入 也是输出  。  cld 指令，清空DF位  将 esi、edi 递增 */
	/*  S 代表 esi 寄存器， c 表示 ecx 寄存器， d 代表 edx 寄存器 */
	asm volatile ("cld;  rep outsw" : "+S"(addr), "+c"(word_cnt) : "d"(port));		// 这个是AT&T汇编，操作数反过来
}


/* 将从端口 port 读入的一个字节返回 */
static inline  uint8_t inb(uint16_t port)
{
	uint8_t data;
	asm volatile ("inb %w1, %b0" : "=a"(data) : "Nd"(port));		// 这个是AT&T汇编，操作数反过来
	return  data;
}

/* 将从端口 port 读入的 word_cnt 字节 写入addr */
static inline void insw(uint16_t port, void* addr, uint32_t word_cnt)
{
	/*  insw 是将从端口port 处读取的16位内容写入 es:edi 指向的内存  */
	/*  + 表示即使输入 也是输出  。  cld 指令，清空DF位  将 esi、edi 递增 */
	/*  D 代表 edi 寄存器， c 表示 ecx 寄存器， d 代表 edx 寄存器 */
	asm volatile ("cld;  rep insw" : "+D"(addr), "+c"(word_cnt) : "d"(port) :"memory");		// 这个是AT&T汇编，操作数反过来
}

#endif