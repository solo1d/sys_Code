#ifndef __LIB_STRING_H
#define __LIB_STRING_H
#include "stdint.h"

/* 将 dst_起始的size 个字节置为 value */
void memset (void* dst_, uint8_t value, uint32_t size);

/* 将 src_ 起始的 size 字节复制到 dst_ */
void memcpy (void* dst_, const void* src_, uint32_t size);

/* 连续比较以地址 a_ 和地址 b_ 开头的 size 个字节， 若相等则返回0，若a_ 大于 b_, 返回 1, 否则返回 -1 */
int memcmp (const void* a_, const void* b_, uint32_t size);

/* 将字符串从 src_ 复制到 dst_ */
char* strcpy(char* dst_, const char* src_);


/* 返回字符串长度 */
uint32_t strlen (const char* str);


/* 比较两个字符串， 若 a 中的字符串大于 b 中的字符返回1， 相等返回0， 否则返回 -1 */
uint8_t strcmp (const char* a, const char* b);


/* 从左到右查找字符串 str 中首次出现字符 ch 的地址 */
char* strchr (const char* str, const uint8_t ch);


/* 从后往前查找字符串 str 中首次出现字符 ch 的地址 */
char* sttrchr (const char* str, const uint8_t ch);

/* 将字符串 src_ 拼接到 dst_ 后， 返回拼接的串地址 */
char* strcat (char* dst_, const char* src_);

/* 在字符串 str 中查找 字符ch 出现的次数 */
uint32_t strchrs (const char* str, uint8_t ch);

#endif  /* __LIB_STRING_H */