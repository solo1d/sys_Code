#include "print.h"
#include "init.h"
#include "debug.h"
#include "memory.h"
void main(void){
    put_str("I am kernel\n");
    init_all();
    // asm volatile("sti");        // 临时开中断

    void* addr = get_kernel_pages(3);
    put_str("\n getkernel_page start vaddr is ");
    put_int((uint32_t)addr);
    put_str("\n");

    // void* addr1 = get_kernel_pages(2);
    // put_str("\n getkernel_page start vaddr is ");
    // put_int((uint32_t)addr1);
    // put_str("\n");

    // void* addr2 = get_kernel_pages(1);
    // put_str("\n getkernel_page start vaddr is ");
    // put_int((uint32_t)addr2);
    // put_str("\n");
    // uint32_t mem_all =  *((uint32_t*)(0xb00));
    // put_int(mem_all);

    while(1)
    {}
}