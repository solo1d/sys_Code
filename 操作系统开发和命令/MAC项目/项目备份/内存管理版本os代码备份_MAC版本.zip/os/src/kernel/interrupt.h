#ifndef __KERNEL_INTERRUPT_H
#define __KERNEL_INTERRUPT_H
#include "stdint.h"
typedef void* intr_handler;
void idt_init(void);

/* 定义中断的两种状态：
 *  INTR_OFF 值为0 ，表示关中断
 *  INTR_ON  值为1 ，表示开中断 */
enum intr_status {		// 中断状态
	INTR_OFF =0 ,       // 中断关闭
	INTR_ON = 1			// 中断打开
};

enum intr_status intr_get_status(void);   /* 将中断状态设置为 status */
enum intr_status intr_set_status(enum intr_status status);   /* 获取当前中断状态 */
enum intr_status intr_enable(void);       /* 开中断 并返回开中断前的状态 */
enum intr_status intr_disable(void);      /* 关中断， 并返回关中断前的状态 */
#endif
