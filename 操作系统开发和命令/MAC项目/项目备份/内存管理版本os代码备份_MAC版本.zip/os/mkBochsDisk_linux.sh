#!/bin/bash
# $1 file name
# $2 img size
bximage -hd -mode="flat" -size=$2 -q $1
