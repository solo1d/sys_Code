#!/bin/bash
#  $1 source file name
#  $2 put file name
ndisasm  $1

# -b32  参数:使用32保护模式下的指令进行反汇编
# -b16  参数:使用16实模式下的指令进行反汇编

